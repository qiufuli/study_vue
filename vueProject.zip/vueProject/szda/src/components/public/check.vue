<template>
<div>
    <div class="demo-input-suffix">
    {{level1}}
    <el-input
        placeholder="请输入内容"
        v-model="input2">
    </el-input>
    </div>
     <div class="demo-input-suffix">
    {{level2}}
    <el-input
        placeholder="请输入内容"
        v-model="input2">
    </el-input>
    </div>
     <div class="demo-input-suffix">
    {{level3}}
    <el-input
        placeholder="请输入内容"
        v-model="input2">
    </el-input>
    </div>
</div>
    
</template>

<script>
export default {

}
</script>

<style>

</style>
