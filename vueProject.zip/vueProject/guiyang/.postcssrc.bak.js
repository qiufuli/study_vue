// https://github.com/michael-ciniawsky/postcss-load-config
// http://postcss.org/ 官网，使用了package.json里面的browserslist浏览器配置
module.exports = {
  "plugins": {
    // to edit target browsers: use "browserlist" field in package.json
    "autoprefixer": {}
  }
}
