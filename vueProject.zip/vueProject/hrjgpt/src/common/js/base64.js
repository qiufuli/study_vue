const Base64 = require("js-base64").Base64;

module.exports.Base64 = Base64;
